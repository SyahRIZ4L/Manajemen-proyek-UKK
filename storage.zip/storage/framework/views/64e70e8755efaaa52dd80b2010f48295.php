<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Edit Profil Admin - Manajemen Proyek</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .profile-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
        }
        
        .profile-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .profile-card .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 1.5rem;
        }
        
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 8px;
            padding: 10px 30px;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(102, 126, 234, 0.3);
        }
        
        .btn-secondary {
            border-radius: 8px;
            padding: 10px 30px;
        }
        
        .form-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 0.5rem;
        }
        
        .form-control, .form-select {
            border-radius: 8px;
            border: 1px solid #dee2e6;
            padding: 0.75rem 1rem;
        }
        
        .alert {
            border-radius: 10px;
            border: none;
        }
        
        .back-btn {
            position: absolute;
            top: 1rem;
            left: 1rem;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 50px;
            padding: 0.5rem 1rem;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .back-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            color: white;
        }
        
        .password-section {
            background-color: #f8f9fa;
            padding: 1.5rem;
            border-radius: 10px;
            margin-top: 1rem;
        }
        
        .section-title {
            color: #667eea;
            font-weight: 600;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #667eea;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="profile-header position-relative">
        <a href="<?php echo e(route('admin.panel')); ?>" class="back-btn">
            <i class="bi bi-arrow-left"></i> Kembali ke Panel
        </a>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="mb-0"><i class="bi bi-person-gear me-3"></i>Edit Profil Admin</h1>
                    <p class="mb-0 mt-2 opacity-75">Kelola informasi profil akun administrator</p>
                </div>
                <div class="col-md-4 text-end">
                    <div class="d-flex align-items-center justify-content-end">
                        <div class="me-3">
                            <i class="bi bi-shield-check display-4"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <!-- Success/Error Messages -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle me-2"></i><?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <strong>Terjadi kesalahan:</strong>
                        <ul class="mb-0 mt-2">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Profile Edit Form -->
                <div class="card profile-card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="bi bi-person-lines-fill me-2"></i>Informasi Profil</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="<?php echo e(route('admin.profile.update')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <!-- Basic Information Section -->
                            <h6 class="section-title">Informasi Dasar</h6>
                            <div class="row mb-4">
                                <div class="col-md-6 mb-3">
                                    <label for="full_name" class="form-label">
                                        <i class="bi bi-person me-1"></i>Nama Lengkap
                                    </label>
                                    <input type="text" class="form-control" id="full_name" name="full_name" 
                                           value="<?php echo e(old('full_name', $user->full_name)); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="username" class="form-label">
                                        <i class="bi bi-at me-1"></i>Username
                                    </label>
                                    <input type="text" class="form-control" id="username" name="username" 
                                           value="<?php echo e(old('username', $user->username)); ?>" required>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label">
                                        <i class="bi bi-envelope me-1"></i>Email
                                    </label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?php echo e(old('email', $user->email)); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="phone" class="form-label">
                                        <i class="bi bi-telephone me-1"></i>Nomor Telepon
                                    </label>
                                    <input type="text" class="form-control" id="phone" name="phone" 
                                           value="<?php echo e(old('phone', $user->phone)); ?>" placeholder="08xxxxxxxxxx">
                                </div>
                            </div>

                            <!-- Personal Information Section -->
                            <h6 class="section-title">Informasi Personal</h6>
                            <div class="row mb-4">
                                <div class="col-md-6 mb-3">
                                    <label for="birth_date" class="form-label">
                                        <i class="bi bi-calendar me-1"></i>Tanggal Lahir
                                    </label>
                                    <input type="date" class="form-control" id="birth_date" name="birth_date" 
                                           value="<?php echo e(old('birth_date', $user->birth_date ? $user->birth_date->format('Y-m-d') : '')); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="gender" class="form-label">
                                        <i class="bi bi-person-badge me-1"></i>Jenis Kelamin
                                    </label>
                                    <select class="form-select" id="gender" name="gender">
                                        <option value="">Pilih Jenis Kelamin</option>
                                        <option value="male" <?php echo e(old('gender', $user->gender) == 'male' ? 'selected' : ''); ?>>Laki-laki</option>
                                        <option value="female" <?php echo e(old('gender', $user->gender) == 'female' ? 'selected' : ''); ?>>Perempuan</option>
                                        <option value="other" <?php echo e(old('gender', $user->gender) == 'other' ? 'selected' : ''); ?>>Lainnya</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="address" class="form-label">
                                    <i class="bi bi-geo-alt me-1"></i>Alamat
                                </label>
                                <textarea class="form-control" id="address" name="address" rows="3" 
                                          placeholder="Masukkan alamat lengkap"><?php echo e(old('address', $user->address)); ?></textarea>
                            </div>

                            <!-- Professional Information Section -->
                            <h6 class="section-title">Informasi Profesional</h6>
                            <div class="mb-4">
                                <label for="bio" class="form-label">
                                    <i class="bi bi-card-text me-1"></i>Bio/Deskripsi
                                </label>
                                <textarea class="form-control" id="bio" name="bio" rows="4" 
                                          placeholder="Ceritakan tentang diri Anda sebagai administrator"><?php echo e(old('bio', $user->bio)); ?></textarea>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6 mb-3">
                                    <label for="website" class="form-label">
                                        <i class="bi bi-globe me-1"></i>Website/Portfolio
                                    </label>
                                    <input type="url" class="form-control" id="website" name="website" 
                                           value="<?php echo e(old('website', $user->website)); ?>" placeholder="https://example.com">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="skills" class="form-label">
                                        <i class="bi bi-gear me-1"></i>Keahlian
                                    </label>
                                    <input type="text" class="form-control" id="skills" name="skills" 
                                           value="<?php echo e(old('skills', is_array($user->skills) ? implode(',', $user->skills) : $user->skills)); ?>" 
                                           placeholder="PHP, Laravel, Project Management (pisahkan dengan koma)">
                                </div>
                            </div>

                            <!-- Password Change Section -->
                            <div class="password-section">
                                <h6 class="section-title">Ubah Password (Opsional)</h6>
                                <p class="text-muted small mb-3">Kosongkan jika tidak ingin mengubah password</p>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="password" class="form-label">
                                            <i class="bi bi-lock me-1"></i>Password Baru
                                        </label>
                                        <input type="password" class="form-control" id="password" name="password" 
                                               placeholder="Masukkan password baru">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="password_confirmation" class="form-label">
                                            <i class="bi bi-lock-fill me-1"></i>Konfirmasi Password
                                        </label>
                                        <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" 
                                               placeholder="Ulangi password baru">
                                    </div>
                                </div>
                            </div>

                            <!-- Action Buttons -->
                            <div class="d-flex justify-content-between mt-4">
                                <a href="<?php echo e(route('admin.panel')); ?>" class="btn btn-secondary">
                                    <i class="bi bi-arrow-left me-2"></i>Batal
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-check-lg me-2"></i>Simpan Perubahan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Auto-hide alerts -->
    <script>
        // Auto hide alerts after 5 seconds
        setTimeout(function() {
            var alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                var bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html><?php /**PATH C:\laragon\www\Manajemen-proyek-UKK\resources\views/admin/profile/edit.blade.php ENDPATH**/ ?>