

<?php $__env->startSection('title', 'My Cards - Boards'); ?>
<?php $__env->startSection('page-title', 'My Cards'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <!-- Header Section -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="mb-1">My Cards</h2>
                    <p class="text-muted mb-0">View your assigned cards organized by boards</p>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-primary" id="refreshBoards">
                        <i class="bi bi-arrow-clockwise"></i> Refresh
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="text-primary mb-2">
                        <i class="bi bi-collection fs-2"></i>
                    </div>
                    <h5 class="mb-0"><?php echo e($stats['total_boards']); ?></h5>
                    <small class="text-muted">Active Boards</small>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="text-info mb-2">
                        <i class="bi bi-card-text fs-2"></i>
                    </div>
                    <h5 class="mb-0"><?php echo e($stats['total_cards']); ?></h5>
                    <small class="text-muted">My Cards</small>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="text-warning mb-2">
                        <i class="bi bi-clock fs-2"></i>
                    </div>
                    <h5 class="mb-0"><?php echo e($stats['in_progress_cards']); ?></h5>
                    <small class="text-muted">In Progress</small>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="text-danger mb-2">
                        <i class="bi bi-eye fs-2"></i>
                    </div>
                    <h5 class="mb-0"><?php echo e($stats['review_cards']); ?></h5>
                    <small class="text-muted">Review</small>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="text-success mb-2">
                        <i class="bi bi-check-circle fs-2"></i>
                    </div>
                    <h5 class="mb-0"><?php echo e($stats['done_cards']); ?></h5>
                    <small class="text-muted">Completed</small>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="text-secondary mb-2">
                        <i class="bi bi-percent fs-2"></i>
                    </div>
                    <h5 class="mb-0"><?php echo e($stats['completion_rate']); ?>%</h5>
                    <small class="text-muted">Completion</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Boards Grid -->
    <div class="row" id="boardsContainer">
        <?php $__empty_1 = true; $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-xl-4 col-md-6 mb-4">
                <div class="card border-0 shadow-sm h-100 board-card" data-board-id="<?php echo e($board->board_id); ?>">
                    <div class="card-header bg-white border-0 pb-0">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="flex-grow-1">
                                <h6 class="mb-1 fw-bold"><?php echo e($board->board_name); ?></h6>
                                <small class="text-muted">
                                    <i class="bi bi-folder me-1"></i><?php echo e($board->project_name); ?>

                                </small>
                            </div>
                            <div class="dropdown">
                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-three-dots"></i>
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item view-board" href="#" data-board-id="<?php echo e($board->board_id); ?>">
                                        <i class="bi bi-eye me-2"></i>View My Cards
                                    </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="card-body pt-2">
                        <?php if($board->description): ?>
                            <p class="text-muted small mb-3"><?php echo e(Str::limit($board->description, 100)); ?></p>
                        <?php endif; ?>
                        
                        <!-- Progress Bar -->
                        <?php
                            $completionRate = $board->my_total_cards > 0 ? 
                                round(($board->my_done_cards / $board->my_total_cards) * 100) : 0;
                        ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <small class="text-muted">My Progress</small>
                                <small class="fw-bold"><?php echo e($completionRate); ?>%</small>
                            </div>
                            <div class="progress" style="height: 6px;">
                                <div class="progress-bar bg-success" style="width: <?php echo e($completionRate); ?>%"></div>
                            </div>
                        </div>

                        <!-- My Cards Statistics -->
                        <div class="row text-center g-2 mb-3">
                            <div class="col-3">
                                <div class="bg-light rounded p-2">
                                    <div class="fw-bold text-primary"><?php echo e($board->my_total_cards); ?></div>
                                    <small class="text-muted">Mine</small>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="bg-light rounded p-2">
                                    <div class="fw-bold text-warning"><?php echo e($board->my_in_progress_cards); ?></div>
                                    <small class="text-muted">Progress</small>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="bg-light rounded p-2">
                                    <div class="fw-bold text-danger"><?php echo e($board->my_review_cards); ?></div>
                                    <small class="text-muted">Review</small>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="bg-light rounded p-2">
                                    <div class="fw-bold text-success"><?php echo e($board->my_done_cards); ?></div>
                                    <small class="text-muted">Done</small>
                                </div>
                            </div>
                        </div>

                        <!-- Action Button -->
                        <button class="btn btn-primary w-100 view-board" data-board-id="<?php echo e($board->board_id); ?>">
                            <i class="bi bi-box-arrow-in-right me-2"></i>View My Cards
                        </button>
                    </div>
                    <div class="card-footer bg-white border-0 pt-0">
                        <small class="text-muted">
                            <i class="bi bi-calendar me-1"></i>
                            Board created <?php echo e($board->created_at ? \Carbon\Carbon::parse($board->created_at)->format('M d, Y') : 'N/A'); ?>

                        </small>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="text-center py-5">
                    <div class="text-muted">
                        <i class="bi bi-collection fs-1 d-block mb-3"></i>
                        <h5>No Cards Found</h5>
                        <p class="mb-3">You don't have any assigned cards yet. Cards will appear here once they are assigned to you by your Team Lead.</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Cards Modal -->
<div class="modal fade" id="cardsModal" tabindex="-1">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title" id="boardModalTitle">My Cards</h5>
                    <small class="text-muted" id="boardModalProject"></small>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="cardsContent">
                    <div class="text-center py-4">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-2">Loading your cards...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Card Detail Modal -->
<div class="modal fade" id="cardDetailModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cardDetailTitle">Card Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="cardDetailContent">
                <!-- Card detail content will be loaded here -->
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // View board cards
    $('.view-board').click(function() {
        const boardId = $(this).data('board-id');
        loadBoardCards(boardId);
    });

    // Refresh boards
    $('#refreshBoards').click(function() {
        location.reload();
    });

    // Handle card detail clicks
    $(document).on('click', '.card-item', function() {
        const cardId = $(this).data('card-id');
        loadCardDetail(cardId);
    });
});

function loadBoardCards(boardId) {
    $('#cardsModal').modal('show');
    $('#cardsContent').html(`
        <div class="text-center py-4">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Loading your cards...</p>
        </div>
    `);

    $.ajax({
        url: `/api/member/my-cards/boards/${boardId}/cards`,
        method: 'GET',
        success: function(response) {
            if (response.success) {
                displayBoardCards(response);
            } else {
                showError('Failed to load cards: ' + response.message);
            }
        },
        error: function(xhr) {
            showError('Error loading cards. Please try again.');
            console.error('Error:', xhr);
        }
    });
}

function displayBoardCards(data) {
    const board = data.board;
    const cardsByStatus = data.cards_by_status;
    const statistics = data.statistics;

    $('#boardModalTitle').text(`${board.board_name} - My Cards`);
    $('#boardModalProject').text(board.project_name);

    let html = `
        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body text-center">
                        <h4>${statistics.total_cards}</h4>
                        <small>My Cards</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-white">
                    <div class="card-body text-center">
                        <h4>${statistics.in_progress_cards}</h4>
                        <small>In Progress</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-danger text-white">
                    <div class="card-body text-center">
                        <h4>${statistics.review_cards}</h4>
                        <small>Review</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body text-center">
                        <h4>${statistics.done_cards}</h4>
                        <small>Completed</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Kanban Board -->
        <div class="row">
    `;

    const statuses = [
        { key: 'todo', title: 'To Do', color: 'secondary' },
        { key: 'in_progress', title: 'In Progress', color: 'warning' },
        { key: 'review', title: 'Review', color: 'danger' },
        { key: 'done', title: 'Done', color: 'success' }
    ];

    statuses.forEach(status => {
        const cards = cardsByStatus[status.key] || [];
        html += `
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header bg-${status.color} text-white">
                        <h6 class="mb-0">${status.title} (${cards.length})</h6>
                    </div>
                    <div class="card-body" style="max-height: 600px; overflow-y: auto;">
        `;

        if (cards.length > 0) {
            cards.forEach(card => {
                const priorityColor = getPriorityColor(card.priority);
                html += `
                    <div class="card mb-2 card-hover card-item" data-card-id="${card.card_id}">
                        <div class="card-body p-3">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h6 class="card-title mb-1">${card.card_title}</h6>
                                <span class="badge bg-${priorityColor}">${card.priority || 'Medium'}</span>
                            </div>
                            ${card.description ? `<p class="card-text small text-muted mb-2">${card.description.substring(0, 100)}${card.description.length > 100 ? '...' : ''}</p>` : ''}
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    <i class="bi bi-person"></i> ${card.creator_name || 'Unknown'}
                                </small>
                                ${card.due_date ? `<small class="text-muted"><i class="bi bi-calendar"></i> ${formatDate(card.due_date)}</small>` : ''}
                            </div>
                            <div class="mt-2">
                                <button class="btn btn-sm btn-outline-primary w-100 card-detail-btn" data-card-id="${card.card_id}">
                                    <i class="bi bi-eye me-1"></i>View Details
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            });
        } else {
            html += `<div class="text-center text-muted py-4">
                <i class="bi bi-inbox fs-3 d-block mb-2"></i>
                <small>No cards in this status</small>
            </div>`;
        }

        html += `
                    </div>
                </div>
            </div>
        `;
    });

    html += `</div>`;
    $('#cardsContent').html(html);

    // Add click handler for card detail buttons
    $('.card-detail-btn').click(function(e) {
        e.stopPropagation();
        const cardId = $(this).data('card-id');
        loadCardDetail(cardId);
    });
}

function loadCardDetail(cardId) {
    $('#cardDetailModal').modal('show');
    $('#cardDetailContent').html(`
        <div class="text-center py-4">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Loading card details...</p>
        </div>
    `);

    $.ajax({
        url: `/api/member/my-cards/cards/${cardId}/detail`,
        method: 'GET',
        success: function(response) {
            if (response.success) {
                displayCardDetail(response);
            } else {
                showError('Failed to load card details: ' + response.message);
            }
        },
        error: function(xhr) {
            showError('Error loading card details. Please try again.');
            console.error('Error:', xhr);
        }
    });
}

function displayCardDetail(data) {
    const card = data.card;
    const timeLogs = data.time_logs;
    const totalTime = data.total_time;
    const comments = data.comments;

    $('#cardDetailTitle').text(card.card_title);

    const priorityColor = getPriorityColor(card.priority);
    const statusColor = getStatusColor(card.status);

    let html = `
        <div class="row">
            <div class="col-md-8">
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="badge bg-${statusColor}">${card.status.toUpperCase()}</span>
                        <span class="badge bg-${priorityColor}">${card.priority || 'Medium'} Priority</span>
                    </div>
                    <h6 class="mb-2">Description</h6>
                    <p class="text-muted">${card.description || 'No description provided'}</p>
                </div>

                <div class="mb-3">
                    <h6 class="mb-2">Project Details</h6>
                    <p class="text-muted mb-1"><strong>Board:</strong> ${card.board_name}</p>
                    <p class="text-muted mb-1"><strong>Project:</strong> ${card.project_name}</p>
                    <p class="text-muted mb-1"><strong>Created by:</strong> ${card.creator_name || 'Unknown'}</p>
                </div>

                ${card.due_date ? `
                <div class="mb-3">
                    <h6 class="mb-2">Due Date</h6>
                    <p class="text-muted">${formatFullDate(card.due_date)}</p>
                </div>
                ` : ''}
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">Time Tracking</h6>
                    </div>
                    <div class="card-body">
                        <p class="mb-2"><strong>Total Time:</strong> ${formatMinutes(totalTime)}</p>
                        <p class="mb-2"><strong>Time Logs:</strong> ${timeLogs.length}</p>
                        ${card.estimated_hours ? `<p class="mb-2"><strong>Estimated:</strong> ${card.estimated_hours}h</p>` : ''}
                    </div>
                </div>
            </div>
        </div>

        ${comments.length > 0 ? `
        <div class="mt-4">
            <h6 class="mb-3">Comments (${comments.length})</h6>
            <div style="max-height: 300px; overflow-y: auto;">
                ${comments.map(comment => `
                    <div class="d-flex mb-3">
                        <div class="flex-shrink-0">
                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                ${comment.full_name.charAt(0).toUpperCase()}
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <strong>${comment.full_name}</strong>
                                <small class="text-muted">${formatFullDate(comment.created_at)}</small>
                            </div>
                            <p class="mb-0">${comment.comment}</p>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
        ` : ''}
    `;

    $('#cardDetailContent').html(html);
}

function getPriorityColor(priority) {
    switch((priority || '').toLowerCase()) {
        case 'high': return 'danger';
        case 'medium': return 'warning';
        case 'low': return 'success';
        default: return 'secondary';
    }
}

function getStatusColor(status) {
    switch(status.toLowerCase()) {
        case 'todo': return 'secondary';
        case 'in_progress': return 'warning';
        case 'review': return 'danger';
        case 'done': return 'success';
        default: return 'secondary';
    }
}

function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function formatFullDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatMinutes(minutes) {
    if (!minutes) return '0m';
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
}

function showSuccess(message) {
    alert(message);
}

function showError(message) {
    alert(message);
}
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.board-card {
    transition: transform 0.2s, box-shadow 0.2s;
    cursor: pointer;
}

.board-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.1) !important;
}

.card-hover {
    transition: transform 0.1s;
    cursor: pointer;
}

.card-hover:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.card-item {
    cursor: pointer;
}

.progress {
    border-radius: 10px;
}

.progress-bar {
    border-radius: 10px;
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('member.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Manajemen-proyek-UKK\resources\views/member/my-cards-boards/index.blade.php ENDPATH**/ ?>